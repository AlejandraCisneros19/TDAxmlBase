
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;


public class VectorXMLBase {
    
    private XMLBase[] vector;
    private XMLBase eliminado;
    
    public VectorXMLBase(){
        vector = new XMLBase[100];
         for(int i=0; i<vector.length;i++){
             vector[i] = new XMLBase();
         }
    }
    
    public boolean insertar(XMLBase data, int indice){
        if(indice>0 && indice<=99){
            vector[indice]=data;
            return true;
        }else{
            return false;
        }
    }
    
    public boolean generarXML(){
        String cadenaDatos="";
        for(int i=0; i<vector.length;i++){
            cadenaDatos += vector[i].getArchivo()+"&"+vector[i].getContenido()+"!!";
        }
        try{
            OutputStreamWriter xml = new OutputStreamWriter(new FileOutputStream("xml.txt"));
            
            xml.write(cadenaDatos);
            xml.close();
            return true;
        }catch(Exception e){
            return false;
        }
    }
    
    public boolean cargarXML(){
        try{
            BufferedReader xml = new BufferedReader(new FileReader ("xml.txt"));
            
            String cadenaDatos = xml.readLine();
            String temporal[] = cadenaDatos.split("!!");
            
            for(int i=0; i<vector.length; i++){
                XMLBase e = new XMLBase();
                String temporal2[] = temporal[i].split("&");
                
                e.setArchivo(temporal2[0]);
                e.setContenido(cadenaDatos);
                vector [i] = e;
            }
            
            return true;
        }catch(Exception e){
            return false;
        }
    }
    
    public boolean eliminar(int indice){
        if(indice>0 && indice<=99){
            eliminado = new XMLBase();
            eliminado = vector[indice];
            vector[indice] = new XMLBase();
            return true;
        }else{
            return false;
        }
    }
    
    public XMLBase mostrarEliminado(){
        return eliminado;
    }
    
    public XMLBase buscar(int indice){
        if(indice>0 && indice<=99){
            return vector[indice];
        }else{
            return null;
        }
    }
    
}
