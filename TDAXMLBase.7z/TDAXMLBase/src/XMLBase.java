
public class XMLBase {
    
    private String archivo;
    private String contenido;
    
    public XMLBase(){
    }

    public String getArchivo() {
        return archivo;
    }

    public void setArchivo(String archivo) {
        this.archivo = archivo;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
       
    
}
